CREATE DATABASE dhq_hospital_project;
USE dhq_hospital_project;

-- main table for raw data --

CREATE TABLE raw_data (
    Activity_ID VARCHAR(20),                  
    District VARCHAR(50),
    Hospital VARCHAR(100),
    Category VARCHAR(50),
    Quarter VARCHAR(20),
    Unit VARCHAR(30),
    Implementing_Agency VARCHAR(50),
    Target INT,
    Achievement INT,
    Achievement_Pct DECIMAL(6,4),

  
  Budget_Allocated_PKR DECIMAL(14,2),
    Budget_Utilized_PKR DECIMAL(14,2),
    Budget_Utilization_Pct DECIMAL(6,4),
    Status VARCHAR(20)
);
-- CSV had % signs and commas in these columns, so DECIMAL wasn't accepting the import --
-- switching to VARCHAR first, will clean the data and convert back later --

ALTER TABLE raw_data MODIFY Achievement_Pct VARCHAR(10);
ALTER TABLE raw_data MODIFY Budget_Utilization_Pct VARCHAR(10);
ALTER TABLE raw_data MODIFY Budget_Allocated_PKR VARCHAR(20);
ALTER TABLE raw_data MODIFY Budget_Utilized_PKR VARCHAR(20);
SHOW TABLES;

-- checking all 14 fields/columns of the table --
DESCRIBE raw_data;

-- check  confirming table exists and data got imported --

SELECT COUNT(*) FROM raw_data;
SELECT * FROM raw_data LIMIT 10;

-- need to update all rows here, so turning safe mode off --

SET SQL_SAFE_UPDATES = 0;

-- removing % signs from the percentage columns --
	
UPDATE raw_data
SET Achievement_Pct = REPLACE(Achievement_Pct, '%', '');
UPDATE raw_data
SET Budget_Utilization_Pct = REPLACE(Budget_Utilization_Pct, '%', '');

-- removing commas from budget figures (e.g. 50,000 -> 50000) --

UPDATE raw_data
SET Budget_Allocated_PKR = REPLACE(Budget_Allocated_PKR, ',', '');
UPDATE raw_data
SET Budget_Utilized_PKR = REPLACE(Budget_Utilized_PKR, ',', '');

-- data is clean now, converting these columns back to DECIMAL for calculations --

ALTER TABLE raw_data MODIFY Achievement_Pct DECIMAL(6,2);
ALTER TABLE raw_data MODIFY Budget_Utilization_Pct DECIMAL(6,2);
ALTER TABLE raw_data MODIFY Budget_Allocated_PKR DECIMAL(14,2);
ALTER TABLE raw_data MODIFY Budget_Utilized_PKR DECIMAL(14,2);

-- check after conversion - values should look like normal numbers now --

SELECT District, MIN(Achievement_Pct) AS Achievement_Pct, MIN(Budget_Allocated_PKR) AS Budget_Allocated_PKR
FROM raw_data
GROUP BY District
ORDER BY District
LIMIT 5;	

-- Logical check: utilized budget should not exceed allocated budget --
SELECT Activity_ID, District, Budget_Allocated_PKR, Budget_Utilized_PKR
FROM raw_data
WHERE Budget_Utilized_PKR > Budget_Allocated_PKR;

-- Logical check: achievement should not exceed target--
SELECT Activity_ID, District, Target, Achievement
FROM raw_data
WHERE Achievement > Target;

-- Analysis --

SELECT District,
       ROUND(AVG(Achievement_Pct), 2) AS Avg_Achievement,
       ROUND(AVG(Budget_Utilization_Pct), 2) AS Avg_Budget_Utilization
FROM raw_data
GROUP BY District
ORDER BY Avg_Achievement DESC;

-- top 5 districts with the most delayed activities --

SELECT District, COUNT(*) AS Delayed_Count
FROM raw_data
WHERE Status = 'Delayed'
GROUP BY District
ORDER BY Delayed_Count DESC, District ASC
LIMIT 5;

-- total budget allocated vs utilized, by category --

SELECT Category,
       SUM(Budget_Allocated_PKR) AS Total_Allocated,
       SUM(Budget_Utilized_PKR) AS Total_Utilized
FROM raw_data
GROUP BY Category;

-- top 5 best performing districts by achievement --

SELECT District, ROUND(AVG(Achievement_Pct), 2) AS Avg_Achievement
FROM raw_data
GROUP BY District
ORDER BY Avg_Achievement DESC
LIMIT 5;

-- bottom 5 districts - these need more attention/follow-up --

SELECT District, ROUND(AVG(Achievement_Pct), 2) AS Avg_Achievement
FROM raw_data
GROUP BY District
ORDER BY Avg_Achievement ASC
LIMIT 5;

-- performance trend quarter by quarter --

SELECT Quarter,
       ROUND(AVG(Achievement_Pct), 2) AS Avg_Achievement,
       ROUND(AVG(Budget_Utilization_Pct), 2) AS Avg_Budget_Utilization
FROM raw_data
GROUP BY Quarter
ORDER BY Quarter;

-- comparing implementing agencies on performance --

SELECT Implementing_Agency,
       ROUND(AVG(Achievement_Pct), 2) AS Avg_Achievement,
       COUNT(*) AS Total_Activities
FROM raw_data
GROUP BY Implementing_Agency
ORDER BY Avg_Achievement DESC;

--  Total number of rows in the table --
SELECT COUNT(*) AS Total_Rows FROM raw_data;

--  Count missing/NULL values in each column --

SELECT
    SUM(CASE WHEN Activity_ID IS NULL OR Activity_ID = '' THEN 1 ELSE 0 END) AS Missing_Activity_ID,
    SUM(CASE WHEN District IS NULL OR District = '' THEN 1 ELSE 0 END) AS Missing_District,
    SUM(CASE WHEN Hospital IS NULL OR Hospital = '' THEN 1 ELSE 0 END) AS Missing_Hospital,
    SUM(CASE WHEN Category IS NULL OR Category = '' THEN 1 ELSE 0 END) AS Missing_Category,
    SUM(CASE WHEN Quarter IS NULL OR Quarter = '' THEN 1 ELSE 0 END) AS Missing_Quarter,
    SUM(CASE WHEN Unit IS NULL OR Unit = '' THEN 1 ELSE 0 END) AS Missing_Unit,
    SUM(CASE WHEN Implementing_Agency IS NULL OR Implementing_Agency = '' THEN 1 ELSE 0 END) AS Missing_Agency,
    SUM(CASE WHEN Target IS NULL THEN 1 ELSE 0 END) AS Missing_Target,
    SUM(CASE WHEN Achievement IS NULL THEN 1 ELSE 0 END) AS Missing_Achievement,
    SUM(CASE WHEN Achievement_Pct IS NULL THEN 1 ELSE 0 END) AS Missing_Achievement_Pct,
    SUM(CASE WHEN Budget_Allocated_PKR IS NULL THEN 1 ELSE 0 END) AS Missing_Budget_Allocated,
    SUM(CASE WHEN Budget_Utilized_PKR IS NULL THEN 1 ELSE 0 END) AS Missing_Budget_Utilized,
    SUM(CASE WHEN Budget_Utilization_Pct IS NULL THEN 1 ELSE 0 END) AS Missing_Budget_Util_Pct,
    SUM(CASE WHEN Status IS NULL OR Status = '' THEN 1 ELSE 0 END) AS Missing_Status
FROM raw_data;

--  Check for duplicate Activity_ID  --
SELECT Activity_ID, COUNT(*) AS Cnt
FROM raw_data
GROUP BY Activity_ID
HAVING COUNT(*) > 1;

--  Check distinct values for consistency (catch spelling/case mismatches) --
SELECT DISTINCT District FROM raw_data ORDER BY District;
SELECT DISTINCT Category FROM raw_data ORDER BY Category;
SELECT DISTINCT Quarter FROM raw_data ORDER BY Quarter;
SELECT DISTINCT Status FROM raw_data ORDER BY Status;
SELECT DISTINCT Implementing_Agency FROM raw_data ORDER BY Implementing_Agency;

-- Check numeric ranges  --
SELECT
    MIN(Achievement_Pct) AS Min_Achievement_Pct,
    MAX(Achievement_Pct) AS Max_Achievement_Pct,
    MIN(Budget_Utilization_Pct) AS Min_Util_Pct,
    MAX(Budget_Utilization_Pct) AS Max_Util_Pct,
    MIN(Budget_Allocated_PKR) AS Min_Allocated,
    MAX(Budget_Allocated_PKR) AS Max_Allocated,
    MIN(Budget_Utilized_PKR) AS Min_Utilized,
    MAX(Budget_Utilized_PKR) AS Max_Utilized
FROM raw_data;



